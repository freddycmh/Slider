import "./App.css";
import WeightedSumForm from "./Components/WeightedSumForm";

function App() {
  return (
    <>
      <WeightedSumForm />
    </>
  );
}

export default App;
